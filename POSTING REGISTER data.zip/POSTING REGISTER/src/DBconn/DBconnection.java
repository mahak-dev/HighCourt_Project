
package DBconn;

import java.sql.Connection;
import java.sql.DriverManager;



public class DBconnection {
    public static void main(String args[]){
        
        
        
          try{
              Class.forName("com.mysql.cj.jdbc.Driver");
              Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/posting_register"
                            , "root","Ankit@1516");
              
              System.out.println("connection established");
          }catch(Exception e) {System.out.println(e);}
        }
    }
 
